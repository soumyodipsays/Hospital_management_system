// Placeholder for future interactions (optional)
document.querySelector('.payment-btn').addEventListener('click', () => {
    alert('Redirecting to payment gateway...');
});
function toggleMenu() {
    const menu = document.querySelector('.menu');
    menu.classList.toggle('active');
}
